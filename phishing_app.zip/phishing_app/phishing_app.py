import streamlit as st
import joblib
import numpy as np
from bs4 import BeautifulSoup
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import urllib.parse
import ipaddress
import bcrypt
import json
import os

# Download NLTK data
nltk.download('stopwords')
nltk.download('wordnet')

# Set Streamlit page config
st.set_page_config(page_title="Phishing Detection App", layout="wide")

# Persistent user storage
USER_FILE = "users.json"

def load_users():
    if os.path.exists(USER_FILE):
        with open(USER_FILE, "r") as f:
            raw = json.load(f)
            return {email: bytes.fromhex(pw) for email, pw in raw.items()}
    return {}

def save_users(users):
    with open(USER_FILE, "w") as f:
        json.dump({email: pw.hex() for email, pw in users.items()}, f)

if "users" not in st.session_state:
    st.session_state.users = load_users()

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "page" not in st.session_state:
    st.session_state.page = "login"

# Auth helper functions
def hash_password(password):
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt())

def check_password(password, hashed):
    return bcrypt.checkpw(password.encode(), hashed)

def show_signup():
    st.title("🔐 Signup")
    email = st.text_input("Email")
    password = st.text_input("Password", type="password")
    if st.button("Create Account"):
        if email in st.session_state.users:
            st.warning("User already exists.")
        else:
            st.session_state.users[email] = hash_password(password)
            save_users(st.session_state.users)
            st.success("Account created! Please log in.")
            st.session_state.page = "login"

def show_login():
    st.title("🔓 Login")
    email = st.text_input("Email")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        if email in st.session_state.users:
            if check_password(password, st.session_state.users[email]):
                st.session_state.logged_in = True
                st.session_state.user_email = email
                st.success(f"Welcome, {email}!")
            else:
                st.error("Incorrect password.")
        else:
            st.error("User not found.")

# Show login/signup if not authenticated
if not st.session_state.logged_in:
    page = st.sidebar.radio("Auth", ["Login", "Signup"])
    if page == "Login":
        show_login()
    else:
        show_signup()
    st.stop()

# Load models and vectorizer
try:
    email_model = joblib.load("improved_email_model.joblib")
    website_model = joblib.load("improved_website_model.joblib")
    email_vectorizer = joblib.load("improved_email_vectorizer.joblib")
except FileNotFoundError as e:
    st.error(f"❌ Error loading model or vectorizer: {e}")
    st.stop()

# Email preprocessing
def preprocess_email(text):
    stopwords_set = set(stopwords.words('english')).union({
        'verify', 'account', 'login', 'click', 'urgent', 'password', 'bank', 'suspend', 'update'
    })
    lemmatizer = WordNetLemmatizer()
    text = BeautifulSoup(text, 'html.parser').get_text()
    text = text.lower()
    text = re.sub(r'http\S+|www\S+|https\S+', '', text)
    text = re.sub(r'[^a-z\s]', '', text)
    words = text.split()
    words = [lemmatizer.lemmatize(w) for w in words if w not in stopwords_set]
    return ' '.join(words)

# URL feature extractor
def extract_features_from_url(url):
    features = []
    parsed = urllib.parse.urlparse(url)
    hostname = parsed.netloc
    path = parsed.path

    def has_ip(domain):
        try:
            ipaddress.ip_address(domain)
            return 1
        except:
            return 0

    features.append(len(url))
    features.append(len(hostname))
    features.append(has_ip(hostname))
    features.append(url.count('.'))
    features.append(url.count('-'))
    features.append(url.count('@'))
    features.append(url.count('?'))
    features.append(url.count('&'))
    features.append(url.count('||'))
    features.append(url.count('='))
    features.append(url.count('_'))
    features.append(url.count('~'))
    features.append(url.count('%'))
    features.append(url.count('/'))
    features.append(url.count('*'))
    features.append(url.count(':'))
    features.append(url.count(','))
    features.append(url.count(';'))
    features.append(url.count('$'))
    features.append(url.count(' '))
    features.append(url.count('www'))
    features.append(url.count('.com'))
    features.append(url.count('//'))
    features.append(1 if 'http' in path else 0)
    features.append(1 if 'https' in url else 0)
    features.append(sum(c.isdigit() for c in url) / len(url))
    features.append(sum(c.isdigit() for c in hostname) / len(hostname) if hostname else 0)
    features.append(1 if 'xn--' in hostname else 0)
    features.append(1 if ':' in hostname else 0)
    features.append(1 if any(tld in path for tld in ['.com', '.org', '.net']) else 0)
    features.append(1 if any(tld in hostname.split('.')[0] for tld in ['com', 'org', 'net']) else 0)
    features.append(1 if len(hostname.split('.')) > 3 else 0)
    features.append(len(hostname.split('.')) - 1)
    features.append(1 if '-' in hostname else 0)
    features.append(0)
    features.append(1 if 'bit.ly' in url or 'tinyurl' in url else 0)
    features.append(1 if '.' in path.split('/')[-1] else 0)

    remaining = 87 - len(features)
    features.extend([0] * remaining)

    return np.array([features])

# --- Streamlit UI ---
st.title("🛡️ Phishing Detection Tool")

option = st.sidebar.radio("Choose Detection Type", ["📧 Email", "🌐 Website URL"])

if option == "📧 Email":
    st.header("📧 Email Phishing Detection")
    subject = st.text_input("Subject")
    body = st.text_area("Email Body", height=200)

    if st.button("Scan Email"):
        combined = subject + " " + body
        clean = preprocess_email(combined)
        vector = email_vectorizer.transform([clean])
        prob = email_model.predict_proba(vector)[0][1]
        percent_phishing = round(prob * 100, 2)
        percent_legit = round((1 - prob) * 100, 2)

        if percent_phishing >= 50:
            st.markdown(f"### 🧠 Prediction: 🚨 Phishing")
            st.progress(prob)
        else:
            st.markdown(f"### 🧠 Prediction: ✅ Legitimate")
            st.progress(1 - prob)

        st.info(f"Confidence: {percent_phishing}% phishing, {percent_legit}% legitimate")

elif option == "🌐 Website URL":
    st.header("🌐 Website URL-Based Detection")
    url = st.text_input("Enter the website URL")

    if st.button("Scan Website"):
        try:
            X = extract_features_from_url(url)
            prediction = website_model.predict(X)[0]
            prob = website_model.predict_proba(X)[0][1]
            percent_phishing = round(prob * 100, 2)
            percent_legit = round((1 - prob) * 100, 2)

            if percent_phishing >= 50:
                st.markdown("### 🧠 Prediction: 🚨 Phishing")
                st.progress(prob)
            else:
                st.markdown("### 🧠 Prediction: ✅ Legitimate")
                st.progress(1 - prob)

            st.info(f"Confidence: {percent_phishing}% phishing, {percent_legit}% legitimate")

        except Exception as e:
            st.error(f"❌ Error processing URL: {e}")
